var jsonData = [
    {
        "q" : "What is the limit of characters for a tweet on Twitter",
        "opt1" : " 110",
        "opt2" : " 140",
        "opt3" : " 120",
        "answer" : "140"
    },
    {
        "q" : "Which type of files cannot be navigated using Clip Art browser ?",
        "opt1" : "AVI",
        "opt2" : "BMP",
        "opt3" : "Mp3",
        "answer" : "Mp3"
    },
    {
        "q" : "Basic Interface in ISDN refers to the transmission speed of ",
        "opt1" : " 144 Kbps",
        "opt2" : "  64 Kbps",
        "opt3" : " 128 Kbps",
        "answer" : " 144 Kbps"
    },
    {
        "q" : "Which of the following is not a logical database structure?",
        "opt1" : "Chain",
        "opt2" : "Tree",
        "opt3" : " Network",
        "answer" :"Chain"
    },
    {
        "q" : "Which of the following is defined by Storage class?",
        "opt1" : "Array ",
        "opt2" : " String",
        "opt3" : "Scope and Performance",
        "answer" : "Scope and Performance"
    }
];