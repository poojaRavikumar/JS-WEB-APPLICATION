var jsonData = [
    {
        "q" : "This essential gas is important so that we can breath",
        "opt1" : " Oxygen",
        "opt2" : " Helium",
        "opt3" : " Carbondioxide",
        "answer" : "Oxygen"
    },
    {
        "q" : "What is the largest planet in the solar system?",
        "opt1" : "Venus",
        "opt2" : "Earth",
        "opt3" : "Jupitor",
        "answer" : "Jupitor"
    },
    {
        "q" : "What part of the plant conducts photosyntehsis?",
        "opt1" : "Branch",
        "opt2" : "Root",
        "opt3" : "Leaf",
        "answer" : "Leaf"
    },
    {
        "q" : "Diabetes develops as the result of a problem with which specific organ in the body?",
        "opt1" : "Liver",
        "opt2" : "Pancreas",
        "opt3" : " Kidney",
        "answer" :"Pancreas"
    },
    {
        "q" : "How many hearts does an octopus have?",
        "opt1" : " 3",
        "opt2" : " 2",
        "opt3" : "1",
        "answer" : "3"
    }
];