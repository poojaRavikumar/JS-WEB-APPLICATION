var jsonData = [
    {
        "q" : "2010 Commonwealth Games held in ?",
        "opt1" : " Canada",
        "opt2" : " India",
        "opt3" : " Britian",
        "answer" : "India"
    },
    {
        "q" : "Who is the first Indian woman to win an Asian Games gold in 400m run?",
        "opt1" : "M.L. Valsammae",
        "opt2" : "Kamaljit Sandhu",
        "opt3" : "P.T. Usha",
        "answer" : "P.T. Usha"
    },
    {
        "q" : "The first Indian to cross seven important seas by swimming ?",
        "opt1" : "Bula Chaudhury",
        "opt2" : " Yuri Gagarin",
        "opt3" : "Amrendra Singh",
        "answer" : "Bula Chaudhury"
    },
    {
        "q" : "Wellington Trophy is related to which game ?",
        "opt1" : "Rowing",
        "opt2" : "Hockey",
        "opt3" : " Polo",
        "answer" :"Rowing"
    },
    {
        "q" : "The 2017 Indian Premier League (IPL 2017) first match on 5 April, 2017 was held in ?",
        "opt1" : " Banglore",
        "opt2" : " Kolkata",
        "opt3" : "Hyderabad",
        "answer" : "Hyderabad"
    }
];