var jsonData = [
    {
        "q" : "Which of the following countries has agreed to accept the payment of export of oil and petroleum products to India, in rupee terms instead of dollar or any other currency?",
        "opt1" : " Kuwait ",
        "opt2" : "  UAE ",
        "opt3" : " Iran ",
        "answer" : "Iran "
    },
    {
        "q" : "Which of the following countries approved a new constitution of the country in a referendum through secret voting held in February 2012?",
        "opt1" : "Syria ",
        "opt2" : "Iran",
        "opt3" : "  UAE ",
        "answer" : "Syria"
    },
    {
        "q" : "The sensitive index of National Stock Exchange of India is popularly known as.... ?",
        "opt1" : "CRIS",
        "opt2" : "SENSEX",
        "opt3" : "NIFTY",
        "answer" : "NIFTY"
    },
    {
        "q" : "Who among the following Indians was conferred the prestigious, National Medal o Arts and Humanities, awarded by US President in February 2012? ",
        "opt1" : " Dr. Montek Singh Ahluwalia ",
        "opt2" : "Dr. Amartya Sen  ",
        "opt3" : " Ms. Meira Kumar ",
        "answer" :"Dr. Amartya Sen"
    },
    {
        "q" : "This Indian state will to go paperless under E Vidhan initiative.",
        "opt1" : " Kerala",
        "opt2" : "Andra Pradesh",
        "opt3" : "Tamil Nadu",
        "answer" : " Kerala"
    }
];